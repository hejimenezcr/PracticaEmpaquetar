package dbistuer;

public class HolaDani{
	public static void main(String[] args){
	System.out.println("Hola mon!");
	}
}

